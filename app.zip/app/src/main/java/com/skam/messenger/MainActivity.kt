package com.skam.messenger

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

private val Purple = Color(0xFF8B5CF6)
private val Deep = Color(0xFF171326)
private val Panel = Color(0xFF241C38)
private val Muted = Color(0xFFB9AECF)

data class Person(val name: String, val detail: String, val messages: MutableList<String> = mutableStateListOf())
enum class Tab { CHATS, CALLS, CONTACTS }

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { SkamApp() }
    }
}

@Composable
fun SkamApp() {
    val people = remember {
        mutableStateListOf(
            Person("Алексей", "+7 900 123-45-67", mutableStateListOf("Привет! Как дела?", "Всё отлично, ты как?")),
            Person("Мария", "@maria_fox", mutableStateListOf("Увидимся вечером 👋")),
            Person("Команда", "Группа · 4 участника", mutableStateListOf("Добро пожаловать в СКАМ!"))
        )
    }
    var selectedTab by remember { mutableStateOf(Tab.CHATS) }
    var selectedPerson by remember { mutableStateOf<Person?>(null) }
    var showAdd by remember { mutableStateOf(false) }
    var calling by remember { mutableStateOf<Person?>(null) }

    MaterialTheme(colorScheme = darkColorScheme(
        primary = Purple, background = Deep, surface = Panel,
        onPrimary = Color.White, onBackground = Color.White, onSurface = Color.White
    )) {
        Surface(Modifier.fillMaxSize(), color = Deep) {
            when {
                calling != null -> CallScreen(calling!!, onEnd = { calling = null })
                selectedPerson != null -> ChatScreen(
                    person = selectedPerson!!,
                    onBack = { selectedPerson = null },
                    onCall = { calling = selectedPerson }
                )
                else -> Column(Modifier.fillMaxSize()) {
                    Row(
                        Modifier.fillMaxWidth().padding(horizontal = 20.dp, vertical = 22.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Column {
                            Text("СКАМ", color = Color.White, fontSize = 30.sp, fontWeight = FontWeight.Black)
                            Text("Твой круг общения", color = Muted, fontSize = 13.sp)
                        }
                        IconButton(onClick = { showAdd = true }) {
                            Icon(Icons.Default.PersonAdd, contentDescription = "Добавить контакт", tint = Purple)
                        }
                    }
                    Row(Modifier.fillMaxWidth().padding(horizontal = 12.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        Tab.entries.forEach { tab ->
                            val label = when(tab) { Tab.CHATS -> "Чаты"; Tab.CALLS -> "Звонки"; Tab.CONTACTS -> "Контакты" }
                            FilterChip(
                                selected = selectedTab == tab,
                                onClick = { selectedTab = tab },
                                label = { Text(label) },
                                leadingIcon = {
                                    Icon(when(tab) {
                                        Tab.CHATS -> Icons.Default.ChatBubble
                                        Tab.CALLS -> Icons.Default.Call
                                        Tab.CONTACTS -> Icons.Default.People
                                    }, null, modifier = Modifier.size(17.dp))
                                },
                                colors = FilterChipDefaults.filterChipColors(
                                    selectedContainerColor = Purple, selectedLabelColor = Color.White,
                                    labelColor = Muted, iconColor = Muted, selectedLeadingIconColor = Color.White
                                )
                            )
                        }
                    }
                    when(selectedTab) {
                        Tab.CHATS -> {
                            Text("ПОСЛЕДНИЕ ДИАЛОГИ", color = Muted, fontSize = 11.sp, fontWeight = FontWeight.Bold,
                                modifier = Modifier.padding(start = 20.dp, top = 24.dp, bottom = 10.dp))
                            LazyColumn(contentPadding = PaddingValues(bottom = 20.dp)) {
                                items(people) { person ->
                                    PersonRow(person, onClick = { selectedPerson = person })
                                }
                            }
                        }
                        Tab.CONTACTS -> {
                            Text("ТВОИ КОНТАКТЫ", color = Muted, fontSize = 11.sp, fontWeight = FontWeight.Bold,
                                modifier = Modifier.padding(start = 20.dp, top = 24.dp, bottom = 10.dp))
                            LazyColumn {
                                items(people) { person -> PersonRow(person, onClick = { selectedPerson = person }) }
                            }
                            Button(onClick = { showAdd = true }, modifier = Modifier.fillMaxWidth().padding(18.dp),
                                colors = ButtonDefaults.buttonColors(containerColor = Purple)) {
                                Icon(Icons.Default.PersonAdd, null); Spacer(Modifier.width(8.dp)); Text("Добавить контакт")
                            }
                        }
                        Tab.CALLS -> {
                            Text("ИСТОРИЯ ЗВОНКОВ", color = Muted, fontSize = 11.sp, fontWeight = FontWeight.Bold,
                                modifier = Modifier.padding(start = 20.dp, top = 24.dp, bottom = 10.dp))
                            Column(Modifier.padding(20.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                                Text("Пока нет звонков", color = Muted)
                                Text("Открой чат и нажми на трубку, чтобы посмотреть демонстрацию звонка.", color = Muted)
                            }
                        }
                    }
                }
            }
        }
    }
    if (showAdd) AddContactDialog(
        onDismiss = { showAdd = false },
        onAdd = { name, identifier ->
            people.add(Person(name.ifBlank { "Новый контакт" }, identifier))
            showAdd = false
            selectedTab = Tab.CONTACTS
        }
    )
}

@Composable
fun PersonRow(person: Person, onClick: () -> Unit) {
    Row(
        Modifier.fillMaxWidth().clickable(onClick = onClick).padding(horizontal = 18.dp, vertical = 12.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box(Modifier.size(48.dp).background(Purple.copy(alpha = .22f), CircleShape), contentAlignment = Alignment.Center) {
            Text(person.name.take(1).uppercase(), color = Purple, fontWeight = FontWeight.Bold, fontSize = 20.sp)
        }
        Column(Modifier.weight(1f).padding(start = 13.dp)) {
            Text(person.name, color = Color.White, fontWeight = FontWeight.SemiBold)
            Text(person.messages.lastOrNull() ?: person.detail, color = Muted, fontSize = 13.sp, maxLines = 1)
        }
        Icon(Icons.Default.ChevronRight, null, tint = Muted)
    }
}

@Composable
fun ChatScreen(person: Person, onBack: () -> Unit, onCall: () -> Unit) {
    var draft by remember { mutableStateOf("") }
    Column(Modifier.fillMaxSize()) {
        Row(Modifier.fillMaxWidth().background(Panel).padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
            IconButton(onClick = onBack) { Icon(Icons.Default.ArrowBack, null, tint = Color.White) }
            Column(Modifier.weight(1f)) {
                Text(person.name, color = Color.White, fontWeight = FontWeight.Bold)
                Text("в СКАМ", color = Muted, fontSize = 12.sp)
            }
            IconButton(onClick = onCall) { Icon(Icons.Default.Call, null, tint = Purple) }
            IconButton(onClick = onCall) { Icon(Icons.Default.Videocam, null, tint = Purple) }
        }
        LazyColumn(Modifier.weight(1f).fillMaxWidth().padding(14.dp), reverseLayout = false,
            verticalArrangement = Arrangement.spacedBy(10.dp)) {
            items(person.messages) { message ->
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.End) {
                    Box(Modifier.widthIn(max = 290.dp).background(Purple, RoundedCornerShape(16.dp)).padding(12.dp)) {
                        Text(message, color = Color.White)
                    }
                }
            }
        }
        Row(Modifier.fillMaxWidth().padding(12.dp).background(Panel, RoundedCornerShape(28.dp)).padding(horizontal = 14.dp, vertical = 8.dp),
            verticalAlignment = Alignment.CenterVertically) {
            BasicTextField(value = draft, onValueChange = { draft = it }, modifier = Modifier.weight(1f),
                textStyle = androidx.compose.ui.text.TextStyle(color = Color.White, fontSize = 15.sp),
                decorationBox = { inner -> if (draft.isEmpty()) Text("Сообщение...", color = Muted); inner() })
            IconButton(onClick = {
                if (draft.isNotBlank()) { person.messages.add(draft.trim()); draft = "" }
            }) { Icon(Icons.Default.Send, null, tint = Purple) }
        }
    }
}

@Composable
fun CallScreen(person: Person, onEnd: () -> Unit) {
    Column(Modifier.fillMaxSize().background(Deep), horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center) {
        Box(Modifier.size(112.dp).background(Purple.copy(alpha = .25f), CircleShape), contentAlignment = Alignment.Center) {
            Text(person.name.take(1).uppercase(), color = Purple, fontSize = 48.sp, fontWeight = FontWeight.Bold)
        }
        Spacer(Modifier.height(22.dp))
        Text(person.name, color = Color.White, fontSize = 26.sp, fontWeight = FontWeight.Bold)
        Text("Демонстрационный звонок", color = Muted, modifier = Modifier.padding(top = 8.dp))
        Spacer(Modifier.height(54.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(30.dp), verticalAlignment = Alignment.CenterVertically) {
            IconButton(onClick = {}) { Icon(Icons.Default.MicOff, null, tint = Color.White) }
            IconButton(onClick = {}) { Icon(Icons.Default.VolumeUp, null, tint = Color.White) }
            IconButton(onClick = onEnd, modifier = Modifier.size(64.dp).background(Color(0xFFE5484D), CircleShape)) {
                Icon(Icons.Default.CallEnd, null, tint = Color.White)
            }
        }
        Text("Звук и видео пока не передаются", color = Muted, fontSize = 12.sp, modifier = Modifier.padding(top = 28.dp))
    }
}

@Composable
fun AddContactDialog(onDismiss: () -> Unit, onAdd: (String, String) -> Unit) {
    var name by remember { mutableStateOf("") }
    var identifier by remember { mutableStateOf("") }
    var method by remember { mutableStateOf("Телефон") }
    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = Panel,
        title = { Text("Новый контакт", color = Color.White) },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                OutlinedTextField(value = name, onValueChange = { name = it }, label = { Text("Имя") }, singleLine = true)
                Text("Добавить по:", color = Muted)
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    listOf("Телефон", "ID СКАМ").forEach {
                        FilterChip(selected = method == it, onClick = { method = it }, label = { Text(it) })
                    }
                }
                OutlinedTextField(value = identifier, onValueChange = { identifier = it },
                    label = { Text(if (method == "Телефон") "Номер телефона" else "Уникальный ID") }, singleLine = true)
                Text("Добавление по IP не используется: IP не является надёжным идентификатором человека и может раскрывать личные данные.", color = Muted, fontSize = 11.sp)
            }
        },
        confirmButton = {
            TextButton(onClick = { if (identifier.isNotBlank()) onAdd(name, identifier) }) { Text("Добавить", color = Purple) }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Отмена", color = Muted) } }
    )
}
